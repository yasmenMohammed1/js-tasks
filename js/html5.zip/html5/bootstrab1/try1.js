// // let imgGrounded=document.getElementById('cardoo');
// // console.log(imgGrounded);
// // imgGrounded.addEventListener('mouseover',function(){
// //     document.getElementById('mynavbar').parentElement.classList.remove('d-none');
// //     console.log('done')
// // })
// // imgGrounded.addEventListener('mouseout',function(){
// //     document.getElementById('mynavbar').parentElement.classList.add('d-none');
// //     console.log('done')
// // })
// let imgGrounded=document.querySelectorAll('[class=nav-item]');
// imgGrounded.addEventListner('click',function(this){console.log(this)})
